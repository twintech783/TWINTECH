function currentUser(){try{return JSON.parse(localStorage.getItem('ss_user')||'null')}catch(e){return null}}
function membership(){try{return JSON.parse(localStorage.getItem('ss_membership')||'null')}catch(e){return null}}
function saveMembership(m){localStorage.setItem('ss_membership',JSON.stringify(m));}
function daysLeft(end){return Math.max(0,Math.ceil((end-Date.now())/86400000));}
document.addEventListener('DOMContentLoaded',()=>{
 const user=currentUser();
 if(document.body.classList.contains('app-bg')&&!user){location.href='login.html';return;}
 const logout=document.getElementById('logoutBtn'); if(logout)logout.addEventListener('click',()=>{localStorage.removeItem('ss_user');location.href='index.html';});
 const plan=membership();
 const dashPlan=document.getElementById('dashPlan');if(dashPlan)dashPlan.textContent=plan?(plan.trial?'Premium trial':plan.name):'Free';
 const name=document.getElementById('profileName'),email=document.getElementById('profileEmail'),about=document.getElementById('profileAbout');
 if(name&&user){name.value=user.name||'';email.value=user.email||'';about.value=user.about||'';}
 const pf=document.getElementById('profileForm');if(pf)pf.addEventListener('submit',e=>{e.preventDefault();const u=currentUser();u.name=name.value.trim();u.about=about.value;localStorage.setItem('ss_user',JSON.stringify(u));const msg=document.getElementById('profileMessage');msg.textContent='Profile saved successfully.';});
 const status=document.getElementById('subscriptionStatus'),trialStatus=document.getElementById('trialStatus');
 function updateMembership(){const m=membership();if(status)status.textContent='Current plan: '+(m?(m.trial?'Premium free trial':m.name):'Free');if(trialStatus){if(m&&m.trial){const d=daysLeft(m.end);trialStatus.textContent=d>0?d+' day(s) left in your free trial. Trial ends on '+new Date(m.end).toLocaleDateString()+'.': 'Your free trial has ended. Choose a plan to continue.';}else trialStatus.textContent='No active free trial.';}}
 updateMembership();
 const trialBtn=document.getElementById('startTrialBtn');if(trialBtn)trialBtn.addEventListener('click',()=>{const old=membership();if(old&&old.trial&&daysLeft(old.end)>0){alert('Your 7-day free trial is already active.');return;}saveMembership({name:'Premium',trial:true,start:Date.now(),end:Date.now()+7*86400000});updateMembership();alert('Your 7-day Premium trial has started! This is a demo trial; no payment is taken.');});
 const choose=(name)=>{saveMembership({name,trial:false,start:Date.now()});updateMembership();alert(name+' plan selected for this demo. No payment has been collected.');};
 const free=document.getElementById('freePlanBtn');if(free)free.addEventListener('click',()=>{saveMembership({name:'Free',trial:false,start:Date.now()});updateMembership();alert('You are now on the Free plan.');});
 const prem=document.getElementById('premiumBtn');if(prem)prem.addEventListener('click',()=>choose('Premium'));
 const pro=document.getElementById('proBtn');if(pro)pro.addEventListener('click',()=>choose('Pro'));
});
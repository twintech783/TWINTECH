# TwinTech – Subscription Demo

A responsive front-end college project demo for a peer-to-peer skill exchange platform.

## Run locally
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Open `index.html` with Live Server (recommended), or use any static web server.

## Subscription features included
- Free, Premium (₹199/month), and Pro (₹499/month) plan display.
- 7-day Premium free-trial button.
- Trial start/end date and remaining days display.
- Plan selection saved in browser localStorage.
- Current plan shown on the dashboard.

## Important limitations
This is a front-end demonstration only. It does NOT collect money, create real subscriptions, or automatically charge users. Trial and plan status are stored in the visitor's browser and can be reset by clearing browser storage. Do not use this as a real paid service without:
- A secure backend and database.
- Authentication and server-side subscription records.
- A payment gateway (for example, Razorpay) and verified payment webhooks.
- Server-side trial eligibility checks, renewal/cancellation handling and receipts.
- Terms, privacy policy, refund and cancellation information.

Demo login/register data is also stored in localStorage. It is not secure production authentication.
